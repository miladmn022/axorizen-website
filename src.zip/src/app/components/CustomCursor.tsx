"use client";

import { useEffect, useState, useCallback } from "react";
import { motion, useMotionValue } from "framer-motion";

export default function CustomCursor() {
  const [enabled, setEnabled] = useState(false);

  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const [isHovering, setIsHovering] = useState(false);

  const moveCursor = useCallback((e: MouseEvent) => {
    mouseX.set(e.clientX);
    mouseY.set(e.clientY);
  }, [mouseX, mouseY]);

  const handleCursorHover = useCallback((e: Event) => {
    if (e instanceof CustomEvent) {
      setIsHovering(e.detail?.isHovering ?? false);
    }
  }, []);

  useEffect(() => {
    const isDesktop = window.innerWidth > 768;
    if (!isDesktop) return;

    setEnabled(true);
    window.addEventListener("mousemove", moveCursor);
    window.addEventListener("cursor-hover", handleCursorHover);

    return () => {
      window.removeEventListener("mousemove", moveCursor);
      window.removeEventListener("cursor-hover", handleCursorHover);
    };
  }, [moveCursor, handleCursorHover]);

  if (!enabled) return null;

  return (
    <motion.div
      className={`
        pointer-events-none fixed z-[9999] top-0 left-0 rounded-full
        ${isHovering ? "w-12 h-12" : "w-4 h-4"}
        bg-white mix-blend-difference
      `}
      style={{
        x: mouseX,
        y: mouseY,
        translateX: "-50%",
        translateY: "-50%",
      }}
    />
  );
}
